@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <form action="">
                <div class="mb-3">
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
    </div>
@endsection
