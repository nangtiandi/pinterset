<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('user.update',$user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="" class="form-label">Role Permission</label>
                            <input type="number" name="role" class="form-control" value="<?php echo e($user->role); ?>" min="0" max="1">
                        </div>
                        <button class="btn btn-primary">Update Permission</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\user\edit.blade.php ENDPATH**/ ?>