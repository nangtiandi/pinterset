<?php $__env->startSection('content'); ?>
    <div class="border-round-0 min-50vh d-md-block d-sm-none" style="position: relative">
        <img src="<?php echo e(asset('img/a.jpg')); ?>" alt="...background-image" style="width: 100%;max-height: 400px">
    </div>
    <div class="container mb-4 mt-md-0 mt-sm-6" style="position: relative">
        <img src="<?php echo e(asset('storage/profile/'.auth()->user()->avatar)); ?>" class="rounded-circle" width="128" style="height:128px;position:absolute;top:-70px">
        <form action="<?php echo e(route('user.photo')); ?>" method="post" enctype="multipart/form-data" id="photoForm" >
            <?php echo csrf_field(); ?>
            <button type="button" class="btn btn-outline-secondary btn-sm" id="photoUpload" style="position: absolute;left: 130px;top: -8px;z-index: 1000">
                <i class="fa fa-plus"></i>
            </button>
            <input type="file" name="photo" id="photoInput" class="d-none">
        </form>
        <div class="position-relative" style="top: 50px">
            <h1 class="font-weight-bold title"><?php echo e(auth()->user()->name); ?></h1>
            <strong style="top: 10px;position: relative;z-index: 1000">
                Bio : <span class="text-muted"><?php echo e(auth()->user()->bio); ?></span>
            </strong>
        </div>
    </div>
    <div class="container mb-5">
        <div class="row my-5">
            <div class="col-md-6 col-xs-12 my-2">
                <div class="card">
                    <div class="card-body">
                        <table class="table align-middle">
                            <div class="d-flex align-items-center">
                                <h4>Please Fill Your Information!</h4>
                            </div>
                            <tr>
                                <td>Name</td>
                                <td><?php echo e(Auth::user()->name); ?></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><?php echo e(Auth::user()->email); ?></td>
                            </tr>
                            <tr>
                                <td>Phone Number</td>
                                <td><?php echo e(Auth::user()->phone); ?></td>
                            </tr>
                            <tr>
                                <td>Your Bio</td>
                                <td><?php echo e(Auth::user()->bio); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xs-12 my-2">
                <div class="card">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('user.profile')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Your Phone Number</label>
                                <input type="tel" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">What is your Bio</label>
                                <textarea name="bio" cols="30" rows="5" class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('bio')); ?></textarea>
                                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button class="btn btn-outline-secondary">Upload Your Profile <i class="fas fa-upload"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\user\profile.blade.php ENDPATH**/ ?>