<?php $__env->startSection('content'); ?>
    <section class="bg-gray200 pt-5 pb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7">
                    <article class="card">
                        <img src="<?php echo e(asset('storage/product/'.$post->photo)); ?>" alt="" class="img-fluid img-thumbnail">
                        <div class="card-body">
                            <h1 class="card-title display-4">
                                <?php echo e($post->title); ?> </h1>
                            <div class="d-flex">
                                <p>Post by <strong><?php echo e($post->user->name); ?>. </strong> </p>
                                <p> Created At <i><?php echo e($post->created_at->diffForHumans()); ?></i></p>
                            </div>
                            <h4 class="my-3">Type :  <?php echo e($post->category->name); ?></h4>
                            <p><?php echo e($post->description); ?></p>
                            <!-- Begin Comments -replace demowebsite with your own id
                            ================================================== -->
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                            <?php endif; ?>
                            <ul class="list-group ">
                                <li class="list-group-item active">
                                    <b>Comments <?php echo e(count($post->comments)); ?></b>
                                </li>
                                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a href="<?php echo e(route('comment.delete',$comment->id)); ?>" class="<?php echo e(auth()->user()->id != $comment->user_id ?? 'd-none'); ?>">
                                            <i class="fa fa-close"></i>
                                        </a>
                                        <?php echo e($comment->comment); ?>

                                        <div class="small mt-2">
                                            By <strong><?php echo e($comment->user->name); ?></strong>,
                                            comment at <?php echo e($comment->created_at->diffForHumans()); ?>

                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php if(auth()->guard()->check()): ?>
                                <div id="comments" class="mt-4">
                                    <div id="disqus_thread">
                                        <form action="<?php echo e(url('comments/add')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="alert alert-danger">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <textarea name="comment" class="form-control mb-2 <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Write Review"></textarea>
                                            <button class="btn btn-primary">Send Review</button>
                                            <a href="<?php echo e(route('/')); ?>" class="text-secondary mx-3">Cancel</a>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!--End Comments
                            ================================================== -->
                        </div>
                    </article>
                </div>
            </div>
        </div>



















    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\user-post.blade.php ENDPATH**/ ?>