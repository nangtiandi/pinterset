<?php $__env->startSection('content'); ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>provider_id</th>
                        <th>avatar</th>
                        <th>role</th>
                        <th>Created At</th>
                        <th>Manage</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>provider_id</th>
                        <th>avatar</th>
                        <th>role</th>
                        <th>Created At</th>
                        <th>Manage</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->phone === null): ?>
                                    <p class="text-danger">Empty Phone!</p>
                                <?php else: ?>
                                    <?php echo e($user->phone); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->provider_id === null): ?>
                                    <p class="text-danger">Not By social login</p>
                                <?php else: ?>
                                    <?php echo e($user->provider_id); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <img src="<?php echo e(asset('storage/profile/'.Auth::user()->avatar)); ?>" alt="" style="width: 50px;height: 50px;border-radius: 8px;object-fit: cover">
                            </td>
                            <td>
                                <?php if($user->role != 1): ?>
                                    <p class="text-white badge bg-danger">User</p>
                                <?php else: ?>
                                    <p class="text-white badge bg-info">Admin</p>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->created_at->format('d/m/y')); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-pen-alt"></i></a>
                                    <form action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <button class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\user\index.blade.php ENDPATH**/ ?>