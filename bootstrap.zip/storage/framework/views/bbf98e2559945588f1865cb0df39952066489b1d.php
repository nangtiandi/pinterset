<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Category Table</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Post Tag</th>
                            <th>Photo</th>
                            <th>Description</th>
                            <th>Owner</th>
                            <th>Post Manage</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Post Tag</th>
                            <th>Photo</th>
                            <th>Description</th>
                            <th>Owner</th>
                            <th>Post Manage</th>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->id); ?></td>
                                <td><?php echo e($post->title); ?></td>
                                <td><p class="badge bg-info text-white"><?php echo e($post->category->name); ?></p></td>
                                <td>
                                    <img src="<?php echo e(asset('storage/product/'.$post->photo)); ?>" alt="" style="width: 50px; height: auto;border-radius: 8px;">
                                </td>
                                <td><?php echo e($post->excerpt); ?></td>
                                <td><p class="small">
                                    <?php if(auth()->user()->role != 1): ?>
                                        <p>**<?php echo e($post->user->name); ?> **</p>
                                        <?php else: ?>
                                        <?php echo e($post->user->name); ?>

                                        <?php endif; ?>
                                        </p></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="<?php echo e(route('post.show',$post->id)); ?>">
                                            <i class="fas fa-eye text-info"></i>
                                        </a>
                                        <a href="<?php echo e(route('post.edit',$post->id)); ?>" class="mx-3">
                                            <i class="fas fa-pen-alt text-warning"></i>
                                        </a>
                                        <form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\post\index.blade.php ENDPATH**/ ?>