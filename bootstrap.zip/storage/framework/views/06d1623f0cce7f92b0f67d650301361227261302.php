<?php $__env->startSection('content'); ?>
    <section class="bg-gray200 pt-5 pb-5">
        <div class="container-fluid mt-5">
            <a href="<?php echo e(route('post.upload')); ?>" class="btn btn-secondary my-3">Upload Post</a>
            <div class="row">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <div class="card-columns">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-pin">
                            <img class="card-img" src="<?php echo e(asset('storage/product/'.$post->photo)); ?>" alt="Card image">
                            <div class="overlay">
                                <h2 class="card-title title"><?php echo e($post->title); ?></h2>
                                <div class="more">
                                    <a href="<?php echo e(route('user.post',$post->id)); ?>">
                                        <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i> More </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\user\post-owner.blade.php ENDPATH**/ ?>