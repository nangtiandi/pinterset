<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="">
                <div class="mb-3">
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\pinterset\resources\views\home.blade.php ENDPATH**/ ?>